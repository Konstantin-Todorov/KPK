﻿namespace CreatePeople2
{
    using System;

    internal enum Gender
    {
        Male,
        Female
    }
}