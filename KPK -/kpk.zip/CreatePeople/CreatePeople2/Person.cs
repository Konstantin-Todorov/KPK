﻿namespace CreatePeople2
{
    using System;

    internal class Person
    {
        public Gender Gender
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public int Age
        {
            get;
            set;
        }
    }
}