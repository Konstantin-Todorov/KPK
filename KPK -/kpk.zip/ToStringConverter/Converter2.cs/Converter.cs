﻿namespace ToStringConverter
{
    using System;

    internal class Converter2
    {
        internal string BoolToString(bool value)
        {
            string valueAsString = value.ToString();
            return valueAsString;
        }
    }
}