﻿namespace Minesweeper
{
    internal class EntryPoint
    {
        internal static void Main()
        {
            Engine.Start();
        }
    }
}